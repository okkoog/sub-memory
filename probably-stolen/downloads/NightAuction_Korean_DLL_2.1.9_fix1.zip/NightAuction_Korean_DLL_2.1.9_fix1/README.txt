Night Auction v2.1.9 Korean DLL - fix1
Original ID: xiaowo_night_auction / Workshop: 3829429358
Corrects missing game art resources and broken Dictionary method reference in the first Korean build.
Original Textures, preview, manifest and en/zh locale files are included.
Replace the entire previous local NightAuction_Korean_DLL_2.1.9 folder with this folder.
Do not load an additional mod copy with the same ID.
Runtime verification inside the actual game is NOT completed.
