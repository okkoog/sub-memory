Probably Stolen - Tentacle mod Korean DLL translation TEST BUILDS (2026-11-21)
Includes 8 DLLs in their corresponding module subdirectories.
Static translation checks completed; game/CLR runtime and save compatibility NOT TESTED.
Keep a backup of original mod DLLs before replacing them.
Source and change log: https://github.com/okkoog/sub-memory/tree/main/probably-stolen/local-mods/TentacleMod%EB%B2%88%EC%97%AD
