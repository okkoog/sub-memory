Probably Stolen Korean translation DLL overlay — NEW six DLLs, 2026-11-21.
These are individual test DLL overlays, not full mod installations.
IMPORTANT: STATIC INSPECTION ONLY. No CLR loader, game, UI or save compatibility tests have been performed.
Replace DLLs only within matching mod folders and back up originals before testing.
All original DLLs in TentacleMod/ were left untouched.
See TentacleMod번역/WORK_PROGRESS.md for audit details and remaining limitations.
