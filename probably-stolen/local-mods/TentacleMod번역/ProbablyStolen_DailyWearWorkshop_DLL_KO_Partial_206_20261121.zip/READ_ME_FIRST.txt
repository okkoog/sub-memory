Probably Stolen DailyWearWorkshop Korean DLL partial translation.
Original 813 active Chinese strings. 206 source strings translated to Korean in the DLL; 607 remain for review or original preservation.
This is NOT a completed localization. Static structure checks only. No CLR/Unity/game run/save tests have been performed.
Install only with the exact matching mod version, and back up the original DLL. Translation TSVs included for review.
Original TentacleMod/ files unchanged.
