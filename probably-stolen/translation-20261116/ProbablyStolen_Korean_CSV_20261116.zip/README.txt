Probably Stolen 한국어 번역팩 - CSV 수정본 (2026-11-16)

아래 5개 파일을 기존 번역팩의 Localization 폴더에 파일명 그대로 덮어씌우세요.
- pskb__3832941698.csv : AI 상업 확장
- pskb__3838820208.csv : More Girls
- pskb__3834588749.csv : 엘리너 스토리
- pskb__3829110153.csv : 낚시 모드
- pskb__3829413447.csv : PC 확장

신규 키 1,453개 / 원문 변경 35개 반영.
GitHub 원본: okkoog/sub-memory / probably-stolen/번역 모드/Localization/
