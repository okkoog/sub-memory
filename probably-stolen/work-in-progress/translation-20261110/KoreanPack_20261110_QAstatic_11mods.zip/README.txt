Probably Stolen KoreanPack localization snapshot (2026-11-10)

This archive contains 11 KoreanPack Localization/pskb__*.csv files.
All 2593 new requested localization entries have been supplied, including MyGO.
Minor Girls was intentionally excluded.
Static key validation: 8128 source keys, 8130 KoreanPack keys (2 extra backward-compatibility keys).
No missing original keys, duplicated keys, placeholder mismatches, markup mismatches, or newline mismatches.
This snapshot is NOT verified by running the game. Some dialogue/style proofreading and on-screen font testing may still be needed.
Only KoreanPack localization data is included. No DLL files and no third-party mod files are modified.
See QA_REVIEW.md for details.
