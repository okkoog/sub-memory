Probably Stolen KoreanPack - 2026-11-10 Manual QA CSV bundle

Contents:
- Localization/: all 11 current KoreanPack localization CSVs, from GitHub main at d9d9eaf2675d23cfa2c18d39362637ed9ff88460
- QA_final_report_20261110.md: comprehensive per-mod summary of 184 text corrections
- README_QA.txt: this description

QA scope: 2,593 newly translated keys individually reviewed in 10 batches (184 corrections).
Across 11 CSV files: 8,130 Korean keys; 8,128 source keys and 2 intentional backward-compatibility keys.
Static source-key, duplicate-key, placeholder, rich-text-markup and newline checks passed at the review checkpoint.

The ZIP contains no DLL or executable code. Steam Workshop has not been updated.
In-game rendering, font coverage, translation runtime behavior, and mod compatibility still require game testing.
Older ZIPs are NOT a substitute for this review checkpoint.

Repo: https://github.com/okkoog/sub-memory/tree/main/probably-stolen/%EB%B2%88%EC%97%AD%20%EB%AA%A8%EB%93%9C/Localization
