Probably Stolen KoreanPack / 2026-11-10 verified release candidate

Contains 11 KoreanPack CSV files and 184-correction QA report.
Fishing Cuisine physical newline row fix included (fce_0b0a364ec14394518dcfc639c8aa37558cd6baaeb0962c65a506b0dedb14f230).
Neon Undertow AFTER HOURS / THE STACK custom interface has not been localized: no source localization keys found; developer API/implementation update is required. Not a completed UI translation.
Do not publish until in-game verification is complete.
No DLL included; Steam Workshop not updated.
