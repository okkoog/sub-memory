Probably Stolen KoreanPack - LOCALIZATION WORK-IN-PROGRESS CHECKPOINT
Snapshot: 2026-11-10.
Korean localization files in this ZIP: 11.
The five new mod translations and MyGO are in scope. Minor Girls is excluded.
Key completeness: 1164 / 2593 localized source keys (manual or prior inspected translations).
Pending: 1429 keys, primarily NPC Girls, Fishing Cuisine Expansion, Cyber Fried Rice.
DO NOT treat this archive as a fully translated release.
All KoreanPack CSV files retain their original bridge M|/W|/K| format.
Only KoreanPack localization is packaged; no third-party DLLs are modified.
Manual new mod subset:
NPC Girls (3835292703): 204 / 817
Fishing Cuisine Expansion (3830031787): 178 / 664
Cyber Fried Rice (3834071305): 143 / 473
