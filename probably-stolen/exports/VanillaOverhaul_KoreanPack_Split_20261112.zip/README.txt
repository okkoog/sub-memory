Vanilla Overhaul - Korean Pack localization split (2026-11-12)
19 files, corresponding to 19 Vanilla Overhaul 0.6.0 modules with Localization/en.csv.
Place the CSV files in the Localization folder of Probably Stolen Korean Pack, not in the original mods.
Framework has no content CSV; Music and Guns also had no English CSV in the GitHub snapshot.
Original all-in-one Neon Undertow translation is archived in GitHub under probably-stolen/maintenance/neon-undertow-legacy-20261112/.
Not verified in game. No DLL files are modified.
