Probably Stolen — GunsmithExpansion Korean localization update (2026-11-12)
Workshop ID: 3834619049
Original comparison input: user-provided latest Localization(1).zip (en.csv/zh.csv)

- 20 existing source keys changed, compared individually.
- 14 Korean translations revised to match the latest source.
- 6 Korean translations checked and retained as already matching.
- 0 new keys.
- 51 keys missing from the latest source retained in KoreanPack pending confirmation of actual feature removal.
- 2 preexisting KoreanPack supplemental keys also retained.
- Original KoreanPack has 279 translation keys; all 279 retained.

INSTALL: Extract Localization/pskb__3834619049.csv and overwrite the same file in the existing KoreanPack Localization directory. The ZIP does not include DLLs or other mod files.
