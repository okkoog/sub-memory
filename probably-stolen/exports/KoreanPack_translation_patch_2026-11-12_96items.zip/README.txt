Probably Stolen KoreanPack — translation patch (2026-11-12)
Source commit: 7796defc78c7b358b1b3faf9cc1f13de2a01fda2

Updated full CSV files:
- CorpPresence (3828913695)
- Faction Reputation Expansion (3828971731)
- Better Item Tooltips (3830180473)
- Eleanor Romance (3834588749)

Extract the Localization directory into the existing KoreanPack mod folder, replacing these four files only.
83 previously missing keys translated; 13 changed source keys reviewed (12 Korean lines revised, 1 retained); 4 removed source keys cleaned up.
This ZIP contains translation data only, not the DLL or a full mod installation.
