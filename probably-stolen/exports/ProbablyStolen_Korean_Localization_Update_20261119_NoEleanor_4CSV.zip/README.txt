Probably Stolen - Korean Localization Update (2026-11-19)
Copy the Localization folder over the Korean translation pack's Localization folder, replacing only these 4 CSV files.
AI Emporium: 19 new keys. Vanilla Gun Expansion: 626 new keys. More Girls: 2 corrected guide image values. Upper Levels: 287 new keys.
Eleanor (3834588749) excluded because the source mod now supports Korean.
Source mods are read-only and were not changed.
