Gunsmith Expansion 2.0.0 Korean localization patch — 2026-11-12
Based on the Nexus Mods 2.0.0 ZIP supplied by the user, not the older Steam workshop DLL.
Contains 465 K| localization keys: 188 new / 35 existing revised / 2 obsolete removed.
Copy Localization/pskb__3834619049.csv to your Probably Stolen Korean Pack's Localization folder.
Do not put this CSV inside the original Gunsmith Expansion mod, and do not replace any Gunsmith DLL.
No game runtime validation; source key sets and formatting placeholders were validated.
