Gunsmith Expansion 2.0.0 Korean translation (Nexus release)
Place the CSV in Probably Stolen Korean Pack/Localization. No original mod DLL changes.
Keys: 465; new 188, revised 35, removed 2. Runtime test not performed.
